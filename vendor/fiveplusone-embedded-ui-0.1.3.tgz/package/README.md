# 嵌入式界面

`@fiveplusone/embedded-ui` 提供样式边界、响应式操作栏、即时提示和装饰图标，适用于嵌入第三方页面的 DOM 界面。操作、请求和保存由业务端处理。

```js
FivePlusOneEmbeddedUI.installBoundary(document, ['#my-panel', '#my-dialog']);
const disposeTips = FivePlusOneEmbeddedUI.installTooltips(document, ['#my-panel', '#my-dialog']);
const toolbar = FivePlusOneEmbeddedUI.enhanceToolbar(document.querySelector('#my-toolbar'), {
  onAction: handleToolbarClick, // 工具栏使用委托事件时，同一处理器也接收菜单中的操作。
});
// 窗口关闭时释放操作栏；应用退出时释放提示。
toolbar.destroy();
disposeTips();
```

边界复位宿主的元素默认样式，组件自身的类样式和内联尺寸保留。操作栏测量容器、按钮及间距，将放不下的操作按原顺序移入“更多”，宽度恢复时展开。按钮保留原节点和事件；分隔项使用 `role="separator"`。

用 `fp-embedded-action-choices` 并列主操作与备选入口，空间不足时自然换行。备选入口使用 `fp-embedded-text-link`，保留链接的键盘焦点和触屏点击区域。

设置项可用 `fp-embedded-setting-row` 放置状态与操作。链接用于打开页面，按钮用于更改设置，两种元素均可使用 `fp-embedded-text-link` 的低强调样式。

即时提示支持 `data-fp-tooltip` 和 `aria-label`，并将既有 `title` 迁移为即时提示。鼠标进入及键盘聚焦时显示，点击、离开、Esc、滚动和缩放时关闭；触屏使用明确标签和至少 44px 的操作目标。菜单支持方向键、Home、End 与 Esc。浮层沿用 `--fp-*` 语义颜色并避让视口边缘。

使用 `renderDecorativeIcon(name)` 在文字旁显示 SVG 图标。支持 `download`、`upload`、`book-open`、`git-branch` 和 `mail`。图标随当前文字颜色和字号变化，操作名称由旁边的文字提供。

```js
const icon = FivePlusOneEmbeddedUI.renderDecorativeIcon('download');
button.innerHTML = `${icon}<span>下载文件</span>`;
```

评阅面板提供标题、收起操作、进度、滚动列表和页脚。宿主提供每项的内容、操作和状态。实时更新时保留同一项的 DOM 节点，让当前焦点和展开状态随该项保留。

```js
const review = FivePlusOneEmbeddedUI.createReviewPanel(document, {
  id: 'my-review', title: '答卷评阅', onClose: () => { review.panel.hidden = true; }
});
FivePlusOneEmbeddedUI.installBoundary(document, ['#my-review']);
FivePlusOneEmbeddedUI.installTooltips(document, ['#my-review']);
document.body.append(review.panel);
review.summary.textContent = '已出建议 1 份';
const row = document.createElement('li');
row.className = 'fp-embedded-review-item';
row.textContent = '第 1 份 · 建议 2 分';
review.list.append(row);
```

在本包目录运行 `npm run build` 和 `npm pack --pack-destination dist`，再通过本地 HTTP 服务打开 `dist/index.html` 查看组件示例和接入代码。浏览器验收覆盖消费项目的宿主样式与完整页面。
